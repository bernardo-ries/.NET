﻿using Microsoft.EntityFrameworkCore;
using PrimeiroProjetoMVC.Models;

namespace PrimeiroProjetoMVC.Views.DAL
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto> options) : base(options)
        {

        }

        DbSet<Produto> Produtos { get; set; }
    }
}

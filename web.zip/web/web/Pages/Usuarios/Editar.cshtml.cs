using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace web.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

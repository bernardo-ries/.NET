using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;

namespace web.Pages.Usuarios
{
    public class CriarModel : PageModel
    {
        [BindProperty] // VINCULA OS DADOS DO FORMULARIO HTML �S PROPIEDADES DO MODELO DA P�GINA QUANDO EU ENVIO UM FORMULARIO PELO METODO POST, O ASP.NET VERIFICA OS VALORES E CAMPOS

        public Usuario usuario {  get; set; } // UM OBJETO PARA SER INSTANCIADO E ARMAZENADO NO ARQUIVO
        public void OnGet()//METODO QUE EXECUTA QUANDO � CHAMADO O METODO GET, OU SEJA, QUANDO ACESSO
        {
        }

        public IActionResult OnPost()// M�TODO QUE EXECUTA QUANDO � FEITO O M�TODO POST
        {
            // VERIFICA SE OS DADOS ENVIADOS NO FORMULARIO S�O V�LIDOS CONFORME AS REGRAS DO MODELO
            if (!ModelState.IsValid)
            {
                return Page();
            }
            else
            {
                //VOU FAZER O ARMAZENAMENTO DESTES DADOS DENTRO DO MEU ARQUIVO TXT
                using (var writer = new StreamWriter("usuarios.txt", true))
                {
                    writer.WriteLine(usuario.Id + ";"+ usuario.Nome + ";" + usuario.Senha + ";" + usuario.Email);
                    return RedirectToPage("/Usuarios/Index");
                }
            }
        }
    }
}

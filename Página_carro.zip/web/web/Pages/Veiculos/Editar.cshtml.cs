using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models; // Importa o modelo "Veiculo" para uso no c�digo

namespace web.Pages.Veiculos
{
    public class EditarModel : PageModel
    {
        // Dados do ve�culo enviados via formul�rio (bind autom�tico)
        [BindProperty]
        public Veiculo Veiculo { get; set; }

        // Imagem enviada no formul�rio (opcional)
        [BindProperty]
        public IFormFile Imagem { get; set; }

        // M�todo GET: executado quando a p�gina � acessada com o Renavam
        public IActionResult OnGet(string renavam)
        {
            // Se o arquivo de ve�culos n�o existir, redireciona para a listagem
            if (!System.IO.File.Exists("veiculos.txt"))
                return RedirectToPage("Index");

            // L� todas as linhas do arquivo
            var linhas = System.IO.File.ReadAllLines("veiculos.txt");

            // Busca a linha do ve�culo com base no Renavam
            var linha = linhas.FirstOrDefault(l => l.Contains(renavam));
            if (linha == null)
                return RedirectToPage("Index");

            // Converte a linha em objeto para exibir no formul�rio
            Veiculo = Veiculo.ConverterParaObjeto(linha);
            return Page(); // Renderiza a p�gina de edi��o
        }

        // M�todo POST: executado quando o formul�rio � enviado
        public IActionResult OnPost()
        {
            // L� o conte�do atual do arquivo
            var veiculos = System.IO.File.ReadAllLines("veiculos.txt").ToList();

            // Encontra o �ndice do ve�culo com o Renavam correspondente
            var index = veiculos.FindIndex(v => v.Contains(Veiculo.Renavam));
            if (index == -1)
                return RedirectToPage("Index"); // N�o encontrado ? redireciona

            // Se uma nova imagem foi enviada, salva no servidor
            if (Imagem != null)
            {
                var pasta = Path.Combine("wwwroot", "uploads");
                if (!Directory.Exists(pasta))
                    Directory.CreateDirectory(pasta); // Cria a pasta, se necess�rio

                var nomeArquivo = Guid.NewGuid().ToString() + Path.GetExtension(Imagem.FileName);
                var caminhoCompleto = Path.Combine(pasta, nomeArquivo);

                // Salva o arquivo no disco
                using (var stream = new FileStream(caminhoCompleto, FileMode.Create))
                {
                    Imagem.CopyTo(stream);
                }

                // Atualiza o caminho da imagem no objeto
                Veiculo.CaminhoImagem = "/uploads/" + nomeArquivo;
            }

            // Substitui a linha original pelos novos dados convertidos em texto
            veiculos[index] = Veiculo.ConverterParaLinha(Veiculo);

            // Salva o conte�do de volta no arquivo
            System.IO.File.WriteAllLines("veiculos.txt", veiculos);

            // Redireciona para a listagem de ve�culos
            return RedirectToPage("Index");
        }
    }
}

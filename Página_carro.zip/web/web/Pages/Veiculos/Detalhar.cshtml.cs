using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;

namespace web.Pages.Veiculos
{
    // Modelo de p�gina para exibir os detalhes de um ve�culo
    public class DetalharModel : PageModel
    {
        // Propriedade que armazenar� o ve�culo encontrado (ligada � View)
        public Veiculo Veiculo { get; set; }

        // M�todo chamado automaticamente ao acessar a p�gina com o par�metro {renavam}
        public IActionResult OnGet(string renavam)
        {
            // Se o arquivo com os ve�culos ainda n�o existir, redireciona para a p�gina de listagem
            if (!System.IO.File.Exists("veiculos.txt"))
                return RedirectToPage("Index");

            // L� todas as linhas do arquivo
            var linhas = System.IO.File.ReadAllLines("veiculos.txt");

            // Procura a primeira linha que contenha o Renavam passado na URL
            var linha = linhas.FirstOrDefault(l => l.Contains(renavam));

            // Se n�o encontrar, redireciona de volta para a listagem
            if (linha == null)
                return RedirectToPage("Index");

            // Converte a linha encontrada em um objeto Veiculo
            Veiculo = Veiculo.ConverterParaObjeto(linha);

            // Renderiza a p�gina normalmente com os dados preenchidos
            return Page();
        }
    }
}

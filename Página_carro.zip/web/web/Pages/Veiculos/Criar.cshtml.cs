// Importa��es necess�rias para Razor Pages, manipula��o de arquivos e modelo de dados
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;

namespace web.Pages.Veiculos
{
    public class CriarModel : PageModel
    {
        // Propriedade que recebe os dados do formul�rio ligados ao modelo Veiculo
        [BindProperty]
        public Veiculo Veiculo { get; set; }

        // Propriedade que recebe a imagem enviada via input file (n�o est� ligada ao modelo diretamente)
        [BindProperty]
        public IFormFile Imagem { get; set; }

        // M�todo executado quando o formul�rio � submetido (HTTP POST)
        public IActionResult OnPost()
        {
            // Se uma imagem foi enviada...
            if (Imagem != null)
            {
                // Define o caminho da pasta onde a imagem ser� salva (dentro de wwwroot/uploads)
                var caminhoPasta = Path.Combine("wwwroot", "uploads");

                // Cria a pasta se ela ainda n�o existir
                if (!Directory.Exists(caminhoPasta))
                    Directory.CreateDirectory(caminhoPasta);

                // Gera um nome �nico para a imagem (evita sobreposi��o de arquivos)
                var nomeArquivo = Guid.NewGuid() + Path.GetExtension(Imagem.FileName);

                // Caminho completo onde o arquivo ser� salvo
                var caminhoCompleto = Path.Combine(caminhoPasta, nomeArquivo);

                // Copia o conte�do da imagem para o local definido no disco
                using (var stream = new FileStream(caminhoCompleto, FileMode.Create))
                {
                    Imagem.CopyTo(stream);
                }

                // Salva o caminho da imagem no objeto Veiculo, para que seja registrado no arquivo
                Veiculo.CaminhoImagem = "/uploads/" + nomeArquivo;
            }

            // Converte o objeto Veiculo em uma linha de texto formatada
            var linha = Veiculo.ConverterParaLinha(Veiculo);

            // Adiciona a linha ao final do arquivo veiculos.txt
            System.IO.File.AppendAllText("veiculos.txt", linha + "\n");

            // Redireciona para a p�gina de listagem ap�s o cadastro
            return RedirectToPage("Index");
        }
    }
}

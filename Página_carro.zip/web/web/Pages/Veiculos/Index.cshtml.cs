using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;

namespace web.Pages.Veiculos
{
    public class IndexModel : PageModel
    {
        // Lista de ve�culos que ser� usada no front-end
        public List<Veiculo> Veiculos { get; set; } = new();

        // M�todo executado quando a p�gina � acessada via GET
        public void OnGet()
        {
            // Verifica se o arquivo de ve�culos existe
            if (System.IO.File.Exists("veiculos.txt"))
            {
                // L� todas as linhas do arquivo
                var linhas = System.IO.File.ReadAllLines("veiculos.txt");

                // Converte cada linha em um objeto Veiculo e adiciona na lista
                foreach (var linha in linhas)
                {
                    Veiculos.Add(Veiculo.ConverterParaObjeto(linha));
                }
            }
        }
    }
}

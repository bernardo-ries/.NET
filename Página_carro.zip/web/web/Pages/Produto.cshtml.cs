using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace web.Pages
{
    public class ProdutoModel : PageModel
    {
        public List<Produto> Produtos { get; set; }

        public void OnGet()
        {
            //Logica para a requis�o GET
            Produtos = new List<Produto>
            {
                new Produto {Descricao = "coca cola", Preco = 8.99m},
                new Produto {Descricao = "Pepsi", Preco = 5.55m},
                new Produto {Descricao = "feij�o", Preco = 3.49m}
            };
        }

    }
    public class Produto
    {
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
    }

}

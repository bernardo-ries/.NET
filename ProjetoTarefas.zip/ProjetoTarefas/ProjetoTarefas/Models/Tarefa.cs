﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjetoTarefas.Models
{
    public class Tarefa
    {
        [Key]
        public int TarefaId { get; set; }

        [Required(ErrorMessage = "O título da tarefa é obrigatório.")]
        [StringLength(100, ErrorMessage = "O título da tarefa deve ter no máximo 100 caracteres.")]
        public string Titulo { get; set; }

        [Required(ErrorMessage = "A descrição da tarefa é obrigatória.")]
        [StringLength(500, ErrorMessage = "A descrição da tarefa deve ter no máximo 500 caracteres.")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "O status da tarefa é obrigatório.")]
        [StringLength(50, ErrorMessage = "O status da tarefa deve ter no máximo 50 caracteres.")]
        public string Status { get; set; }

        [Required(ErrorMessage = "O projeto é obrigatório.")]
        [ForeignKey("Projeto")]
        public int ProjetoId { get; set; }

        public Projeto Projeto { get; set; }
    }
}
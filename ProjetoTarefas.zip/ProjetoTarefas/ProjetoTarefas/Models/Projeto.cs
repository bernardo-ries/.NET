﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjetoTarefas.Models
{
    public class Projeto
    {
        [Key]
        public int ProjetoId { get; set; }

        [Required(ErrorMessage = "O nome do projeto é obrigatório.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O cliente é obrigatório.")]
        public string Cliente { get; set; }

        [Required(ErrorMessage = "A data de início é obrigatória.")]
        [DataType(DataType.Date)]
        public DateTime DataInicio { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DataTermino { get; set; }

        public ICollection<Tarefa> Tarefas { get; set; } = new List<Tarefa>();
    }
}
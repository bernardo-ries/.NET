﻿// Define o namespace do projeto onde essa classe está localizada
namespace web.Models
{
    // Classe que representa um veículo no sistema
    public class Veiculo
    {
        // Propriedades obrigatórias para cada veículo
        public string Nome { get; set; }               
        public string Modelo { get; set; }             
        public string Marca { get; set; }              
        public string Renavam { get; set; }            
        public int AnoFabricacao { get; set; }         
        public int AnoModelo { get; set; }             
        public string CaminhoImagem { get; set; }      

        // Método que converte um objeto Veiculo para uma linha de texto estruturada (para salvar no .txt)
        public static string ConverterParaLinha(Veiculo v)
        {
            // Retorna os dados separados por ponto e vírgula, no mesmo formato em que são salvos no arquivo
            return $"{v.Nome};{v.Modelo};{v.Marca};{v.Renavam};{v.AnoFabricacao};{v.AnoModelo};{v.CaminhoImagem}";
        }

        // Método que converte uma linha do arquivo texto em um objeto Veiculo
        public static Veiculo ConverterParaObjeto(string linha)
        {
            // Divide a linha em partes usando o caractere ';' como separador
            var partes = linha.Split(';');

            // Verifica se a linha tem pelo menos 7 partes e se os campos obrigatórios (nome e renavam) não estão vazios
            if (partes.Length < 7 || string.IsNullOrWhiteSpace(partes[0]) || string.IsNullOrWhiteSpace(partes[3]))
            {
                // Se a linha estiver incompleta ou corrompida, retorna um veículo genérico com dados neutros
                return new Veiculo
                {
                    Nome = "-",
                    Modelo = "-",
                    Marca = "-",
                    Renavam = "-",
                    AnoFabricacao = 0,
                    AnoModelo = 0,
                    CaminhoImagem = ""
                };
            }

            // Cria e retorna um novo objeto Veiculo preenchido com os dados da linha
            return new Veiculo
            {
                Nome = partes[0],
                Modelo = partes[1],
                Marca = partes[2],
                Renavam = partes[3],
                AnoFabricacao = int.TryParse(partes[4], out int anoFab) ? anoFab : 0,
                AnoModelo = int.TryParse(partes[5], out int anoMod) ? anoMod : 0,
                CaminhoImagem = partes[6]
            };
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;
using Microsoft.AspNetCore.Hosting;

namespace web.Pages.Veiculos
{
    public class EditarModel : PageModel
    {
        private readonly IWebHostEnvironment _env;

        public EditarModel(IWebHostEnvironment env)
        {
            _env = env;
        }

        [BindProperty]
        public Veiculo Veiculo { get; set; }

        [BindProperty]
        public IFormFile Imagem { get; set; }

        public IActionResult OnGet(string renavam)
        {
            var caminhoArquivo = Path.Combine(_env.ContentRootPath, "veiculos.txt");

            if (!System.IO.File.Exists(caminhoArquivo))
                return RedirectToPage("Index");

            var linhas = System.IO.File.ReadAllLines(caminhoArquivo);
            var linha = linhas.FirstOrDefault(l => l.Contains(renavam));
            if (linha == null)
                return RedirectToPage("Index");

            Veiculo = Veiculo.ConverterParaObjeto(linha);
            return Page();
        }

        public IActionResult OnPost()
        {
            var caminhoArquivo = Path.Combine(_env.ContentRootPath, "veiculos.txt");
            var veiculos = System.IO.File.ReadAllLines(caminhoArquivo).ToList();

            var index = veiculos.FindIndex(v => v.Contains(Veiculo.Renavam));
            if (index == -1)
                return RedirectToPage("Index");

            if (Imagem != null)
            {
                var pasta = Path.Combine(_env.WebRootPath, "uploads");
                if (!Directory.Exists(pasta))
                    Directory.CreateDirectory(pasta);

                var nomeArquivo = Guid.NewGuid().ToString() + Path.GetExtension(Imagem.FileName);
                var caminhoCompleto = Path.Combine(pasta, nomeArquivo);

                using (var stream = new FileStream(caminhoCompleto, FileMode.Create))
                {
                    Imagem.CopyTo(stream);
                }

                Veiculo.CaminhoImagem = "/uploads/" + nomeArquivo;
            }

            veiculos[index] = Veiculo.ConverterParaLinha(Veiculo);
            System.IO.File.WriteAllLines(caminhoArquivo, veiculos);

            return RedirectToPage("Index");
        }
    }
}
